<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="1" tilewidth="32" tileheight="32" tilecount="1092" columns="26">
 <image source="person.png" width="832" height="1344"/>
</tileset>
